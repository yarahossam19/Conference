$(document).ready(function () {;
    $('#example').DataTable({
        aLengthMenu: [
            [5 ,25, 50, 100, 200],
            [5, 25, 50, 100, 200]
        ],
    });
});

$(document).ready(function () {;
    $('#example2').DataTable({
        aLengthMenu: [
            [5 ,25, 50, 100, 200],
            [5, 25, 50, 100, 200]
        ],
    });
});